#!/bin/bash

if ps aux |grep -i cr[0]n > /dev/null ; then
        exit 0
else
    exit 2
fi
