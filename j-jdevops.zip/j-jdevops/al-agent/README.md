# al-agent

This Cookbook configures and installs al-agent service.

Requirements

	The following platforms are tested directly under test kitchen.

	centos-6.7
	centos-7.2
	RHEL-7

Dependencies

	Al-agent helpers resource file.

Attributes

	default['al_agents']['package']['apikey'] --  your required registration key. String defaults to your_registration_key_here


Testing

	In the root of the project:
	  To execute test kitchen: kitchen test
