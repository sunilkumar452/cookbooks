#
# Cookbook Name:: al-agent
# Recipe:: default
#
# Copyright (c) 2016 The Authors, All Rights Reserved.
::Chef::Recipe.send(:include, AlAgents::Helpers)
cache_dir = Chef::Config[:file_cache_path]
cached_package = ::File.join(cache_dir, agent_basename)

remote_file agent_basename do
  extend(AlAgents::Helpers)
  path "/tmp/#{agent_basename}" 
  source node['al_agents']['package']['url']
  action :create_if_missing
end

package agent_basename do
  extend(AlAgents::Helpers)
  source "/tmp/#{agent_basename}"
  action :install
  version '>=0'
  provider Chef::Provider::Package::Dpkg if node['platform_family'] == 'debian'
  provider Chef::Provider::Package::Rpm if node['platform_family'] == 'rhel' && node['platform_version'].to_i >= 6
end
api_key = node['al_agents']['package']['apikey']
al_home_dir = "/var/alertlogic"
al_bin_dir = "#{al_home_dir}/lib/bin"
al_etc_dir = "#{al_home_dir}/etc"

if api_key =~ /^[a-zA-Z0-9]{50}$/
   execute "Trigger AL agent api key update" do
      #path [ "#{al_bin_dir}" ]
	  command "echo 'our Alert logic API key has changed'"
      only_if "bash -c 'al-agent print-config | grep host_uuid.*undefined'"
   end
   execute "stop al-service" do
      command "/etc/init.d/al-agent stop"
   end
   execute "Delete all certs" do
	  command "rm -rf #{al_etc_dir}/host*.pem"
   end
   execute "Run AL configure" do 
      #path [ "#{al_bin_dir}" ]
	  command "/etc/init.d/al-agent configure --key #{api_key}"
   end
   execute "Run Al Provision" do 
      #path [ "#{al_bin_dir}" ]
	  command "/etc/init.d/al-agent provision --inst-type host"
      notifies :run, 'execute[start_al-service]', :immediately
   end
else 
   execute "invalid key" do
      command "echo 'invalid key'"
   end
end
   
execute "start_al-service" do
      command "/etc/init.d/al-agent restart"
end
