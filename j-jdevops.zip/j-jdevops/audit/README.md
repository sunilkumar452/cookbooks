# audit

Chef cookbook to configure auditd service

## Supported Platforms:
 
- Centos-7.2
- Centos-6.7

## Cookbook Dependencies:
 
  No dependencies

## Attributes:

<table>
  <tr>
    <th>Key</th>
    <th>Type</th>
    <th>Description</th>
    <th>Default</th>
  </tr>
  <tr>
    <td><tt>[:audit][:auditd_home]</tt></td>
    <td>String</td>
    <td>auditd.config home</td>
    <td><tt>/etc/audit</tt></td>
  </tr>
  <tr>
    <td><tt>[:audit][:syslog_home]</tt></td>
    <td>String</td>
    <td>syslog.config home</td>
    <td><tt>/etc/audisp/plugins.d/</tt></td>
  </tr>
  <tr>
    <td><tt>[:audit][:rules_home]</tt></td>
    <td>String</td>
    <td>auditd.config file home</td>
    <td><tt>/etc/audit for Centos 6 versions and /etc/audit/rules.d for Centos 7 versions</tt></td>
  </tr>
<table>

## Recipes

### audit::default

Configures auditd daemon, audit rules and syslog plugin.

### Usage

Add the audit cookbook as a dependency

```
depends 'audit'
```

Include the audit::default recipe

include_recipe 'audit::default'


## License and Authors:

Author:: Naresh Parimi (naresh.parimi@relevancelab.com)
