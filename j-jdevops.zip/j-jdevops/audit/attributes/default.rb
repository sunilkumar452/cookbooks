#Audit default attributes

default[:audit][:auditd_home] = '/etc/audit'
default[:audit][:syslog_home] = '/etc/audisp/plugins.d'

if node[:platform_version].to_i == 6
  default[:audit][:rules_home] = '/etc/audit'
elsif node[:platform_version].to_i == 7
  default[:audit][:rules_home] = '/etc/audit/rules.d'
end
