#
# Cookbook Name:: audit
# Recipe:: default
#
# Copyright (c) 2016 The Authors, All Rights Reserved.

%W{#{node[:audit][:auditd_home]} #{node[:audit][:syslog_home]} #{node[:audit][:rules_home]}}.each do |dir|
  directory dir do
  	owner 'root'
  	group 'root'
  	mode '0640'
  end
end

cookbook_file "#{node[:audit][:auditd_home]}/auditd.config" do
  source 'auditd.config'
  owner 'root'
  group 'root'
  mode '0640'
  notifies :enable, 'service[auditd]', :immediately
  notifies :start, 'service[auditd]', :immediately
end

cookbook_file "#{node[:audit][:syslog_home]}/syslog.config" do
  source 'syslog.config'
  owner 'root'
  group 'root'
  mode '0640'
  notifies :enable, 'service[auditd]', :immediately
  notifies :start, 'service[auditd]', :immediately
end

cookbook_file "#{node[:audit][:rules_home]}/audit.rules" do
  source 'audit.rules'
  owner 'root'
  group 'root'
  mode '0640'
  notifies :enable, 'service[auditd]', :immediately
  notifies :start, 'service[auditd]', :immediately
end

service 'auditd' do
  action [:enable, :start]
end
