#
# Cookbook Name:: audit
# Spec:: default
#
# Copyright (c) 2016 The Authors, All Rights Reserved.

require 'chefspec'
describe 'audit::default' do
  let(:chef_run) { ChefSpec::SoloRunner.new.converge(described_recipe) }

  it "check if directory is created" do
['/etc/audit', '/etc/audisp/plugins.d', '/etc/audit'].each do |dir|
expect(chef_run).to create_directory("#{dir}") do
    end
end
end


it 'creates a cookbook_file' do
      expect(chef_run).to create_cookbook_file('/etc/audit/auditd.config').with(
        user: 'root',
        group: 'root',
        mode: '0640'
        )
    resource = chef_run.cookbook_file('/etc/audit/auditd.config')
expect(resource).to notify('service[auditd]').to(:enable).immediately

end

it 'creates a cookbook_file' do
      expect(chef_run).to create_cookbook_file('/etc/audisp/plugins.d/syslog.config').with(
        user: 'root',
        group: 'root',
        mode: '0640'
     )
  resource = chef_run.cookbook_file('/etc/audisp/plugins.d/syslog.config')
expect(resource).to notify('service[auditd]').to(:enable).immediately

end

describe 'When all attributes are default, on an RHEL6 platform' do
    let(:chef_run) { ChefSpec::SoloRunner.new(platform: 'redhat', version: '6.0').converge(described_recipe) }

 it 'creates a cookbook_file' do
      expect(chef_run).to create_cookbook_file('/etc/audit/audit.rules').with(
        user: 'root',
        group: 'root',
        mode: '0640'
     )
 resource = chef_run.cookbook_file('/etc/audit/audit.rules')
expect(resource).to notify('service[auditd]').to(:enable).immediately

    end
end

describe 'When all attributes are default, on an RHEL6 platform' do
    let(:chef_run) { ChefSpec::SoloRunner.new(platform: 'redhat', version: '7.0').converge(described_recipe) }

it 'creates a cookbook_file' do
      expect(chef_run).to create_cookbook_file('/etc/audit/rules.d/audit.rules').with(
        user: 'root',
        group: 'root',
        mode: '0640'
     )
  resource = chef_run.cookbook_file('/etc/audit/rules.d/audit.rules')
expect(resource).to notify('service[auditd]').to(:enable).immediately

    end
end

 it "should check service" do
    expect(chef_run).to start_service('auditd')
end
end