# # encoding: utf-8

# Inspec test for recipe audit::default

# The Inspec reference, with examples and extensive documentation, can be
# found at https://docs.chef.io/inspec_reference.html

if !os.windows?
  describe user('root') do
    it { should exist }
  end
end

control 'file test' do
  impact 0.3
  title 'Check audit files and permissions'
  desc 'This is will check audit files and permissions'
  
  files = %w{/etc/audit/auditd.config /etc/audisp/plugins.d/syslog.config}
  
  files.each do |f|
    describe file(f) do
    	it { should exist }
	    it { should be_file }
	    its('owner') { should eq 'root' }
	    its('group') { should eq 'root' }
	    its('mode') { should cmp '0640' }
    end
  end
end

control 'test audit.rules file for centos-6.7 (OR) centos-7.2' do
  impact 0.3
  title 'Check audit.rules file and permissions'
  desc 'This is will audit the audit.rules file and permissions'
	describe.one do
		describe file("/etc/audit/audit.rules") do
		  it { should exist }
		  it { should be_file }
		  its('owner') { should eq 'root' }
		  its('group') { should eq 'root' }
		  its('mode') { should cmp '0640' }
		end

		describe file("/etc/audit/rules.d/audit.rules") do
		  it { should exist }
		  it { should be_file }
		  its('owner') { should eq 'root' }
		  its('group') { should eq 'root' }
		  its('mode') { should cmp '0640' }
		end
	end
end

control 'Test audit rules' do
  impact 0.3
  title 'Check some of the listed audit daemon rules'
  
	describe auditd_rules do
	  its('lines') { should contain_match('-w /etc/ssh/sshd_config/') }
	end
end

describe service('auditd') do
  it { should be_enabled }
  it { should be_running }
end
