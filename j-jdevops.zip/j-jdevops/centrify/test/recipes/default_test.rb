describe file('/etc/centrifydc/centrifydc.conf') do
  it { should be_file }
  its('owner') { should eq 'root' }
  its('group') { should eq 'root' }
  its('mode') { should cmp '0644' }
end

describe file('/etc/centrifydc/user.ignore') do
  it { should be_file }
end
describe service('centrifydc') do
  it { should be_running }
end