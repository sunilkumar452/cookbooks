# -*- coding: utf-8 -*-

default['hostname_cookbook']['use_node_ip'] = false
default['hostname_cookbook']['hostsfile_ip'] = '10.0.2.15'
default['hostname_cookbook']['hostsfile_ip_interface'] = 'lo0' if platform == 'freebsd'
default['hostname_cookbook']['set_fqdn'] = "praneeta-kumari.gmail.com"
