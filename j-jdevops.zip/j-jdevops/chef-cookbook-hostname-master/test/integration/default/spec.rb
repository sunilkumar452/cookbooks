control 'Hostname' do
  title 'Test hostname'
	describe host('praneeta-kumari.gmail.com') do
  		it { should be_resolvable }
		it { should be_reachable }
		its(:ipaddress) { should include '10.0.2.15' }
	end
end