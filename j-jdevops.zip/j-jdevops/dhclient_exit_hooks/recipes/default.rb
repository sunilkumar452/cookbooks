#
# Cookbook Name:: dhclient_exit_hooks
# Recipe:: default
#
# Copyright (c) 2016 The Authors, All Rights Reserved.

cookbook_file '/etc/dhcp/dhclient-exit-hooks' do
  source 'dhclient-exit-hooks'
  owner 'root'
  group 'root'
  mode '0755'
  action :create
  notifies :run, 'execute[reread_dhclient]', :immediately
end

execute "reread_dhclient" do
   command "/sbin/dhclient-script MEDIUM"
end


