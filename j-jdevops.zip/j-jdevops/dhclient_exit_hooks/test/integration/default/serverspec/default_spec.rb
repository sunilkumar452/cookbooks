require 'spec_helper'

describe 'dhclient_exit_hooks::default' do
  # Serverspec examples can be found at
  # http://serverspec.org/resource_types.html
  # it 'does something' do
    # skip 'Replace this with meaningful tests'
  # end
  describe file('/etc/dhcp/dhclient-exit-hooks') do
   it { should be_file }
  end

end
