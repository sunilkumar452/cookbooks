describe file('/etc/dhcp/dhclient-exit-hooks') do
  it { should be_file }
end
describe bash('/sbin/dhclient-script MEDIUM') do
  its('exit_status') { should eq 0 }
end
