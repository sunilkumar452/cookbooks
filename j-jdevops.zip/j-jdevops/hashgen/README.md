# hashgen


This Cookbook creates rancher file with scm_account values in directory /opt/jnj/its_core/hashgen

Requirements

	The following platforms are tested directly under test kitchen.

	centos-6.7
	centos-7.2
	RHEL-7

Template file 

	generate.sh.erb is needed.
	Variables scm_account is passed after regular expression parsing of hostname in chef recipe.
	
Testing

	In the root of the project:
	  To execute test kitchen: kitchen test