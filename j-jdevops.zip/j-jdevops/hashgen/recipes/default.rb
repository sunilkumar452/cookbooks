#
# Cookbook Name:: hashgen
# Recipe:: default
#
# Copyright (c) 2016 The Authors, All Rights Reserved.

# hashgen should only execute when
#   its_core::exceptions::container_host = 'true'
hostname = "aws031nva1138"
scm_account = hostname.match(/^(...)(...)(...)(\d+$)/)[2]

if node['its_core']['exceptions']['container_host'] == true
  base_dir = '/opt/jnj/its_core/hashgen'
  directory "#{base_dir}" do
   owner 'root'
   group 'root'
   mode '0700'
   recursive true
   action :create
  end
  template "#{base_dir}/generate.sh" do
   source 'generate.sh.erb'
   owner 'root'
   group 'root'
   mode '0700'
   variables({
     :scm_account => "#{scm_account}"
   })
  end
  execute "ITS_Core_Generate_Hash" do
   command "#{base_dir}/generate.sh > #{base_dir}/generate.log"
   only_if 'test -f "#{base_dir}/generate.sh" -a -s "#{base_dir}/generate.sh"'
  end
end