#
# Cookbook Name:: hashgen
# Spec:: default
#
# Copyright (c) 2016 The Authors, All Rights Reserved.

require 'spec_helper'

describe 'hashgen::default' do
    let(:chef_run) do
      runner = ChefSpec::ServerRunner.new
      runner.converge(described_recipe)
    end
    base_dir="/opt/jnj/its_core/hashgen"
    it 'converges successfully' do
      stub_command('test -f "#{base_dir}/generate.sh" -a -s "#{base_dir}/generate.sh"').and_return(true)
      expect { chef_run }.to_not raise_error
    end

	it "check if directory is created" do
    stub_command('test -f "#{base_dir}/generate.sh" -a -s "#{base_dir}/generate.sh"').and_return(true)
  		expect(chef_run).to create_directory('/opt/jnj/its_core/hashgen').with(
        user: 'root',
        group: 'root',
        mode: '0700'
     )
	end

    it "should check if template is created" do
      stub_command('test -f "#{base_dir}/generate.sh" -a -s "#{base_dir}/generate.sh"').and_return(true)
    	expect(chef_run).to create_template('/opt/jnj/its_core/hashgen/generate.sh')
	end

  it 'ITS_Core_Generate_Hash' do  
      stub_command('test -f "#{base_dir}/generate.sh" -a -s "#{base_dir}/generate.sh"').and_return(true) 
    expect(chef_run).to run_execute("#{base_dir}/generate.sh > #{base_dir}/generate.log")
  end
  end

