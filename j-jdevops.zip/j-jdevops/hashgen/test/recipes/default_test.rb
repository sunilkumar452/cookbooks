
describe directory('/opt/jnj/its_core/hashgen') do
   it { should be_directory }
   its('owner') { should eq 'root' }
   its('group') { should eq 'root' }
   its('mode') { should cmp '0700' }
end

describe file('/opt/jnj/its_core/hashgen/generate.sh') do
   it { should be_file }
   its('owner') { should eq 'root' }
   its('group') { should eq 'root' }
   its('mode') { should cmp '0700' }
end

