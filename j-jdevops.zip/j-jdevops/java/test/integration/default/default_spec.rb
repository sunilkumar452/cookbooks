

#
# Cookbook Name:: spec
# Spec:: default
#
# Copyright (c) 2016 Praneeta Kumari, All Rights Reserved.

control 'java-2.0' do
  title 'run java from specific path'
  describe command('which java') do
    its(:stdout) { should match(%r{/bin/java}) }
  end

  describe command('java -version') do
    its(:stderr) { should match('1.7.0_111') }
  end

   describe command('/etc/profile.d/jdk.sh && echo $JAVA_HOME') do
    its(:stdout) { should match('/usr/lib/jvm/java-1.7.0') }
  end

  end



