#
# Cookbook Name:: spec
# Spec:: default
#
# Copyright (c) 2016 The Authors, All Rights Reserved.

require 'chefspec'
describe 'jboss7::default' do
 let (:chef_run) { ChefSpec::SoloRunner.new.converge(described_recipe)}


 it "includes correct recipe" do
 expect(chef_run).to include_recipe('apt')
 end

it "includes correct recipe" do
 expect(chef_run).to include_recipe('java')
 end
  
it "check if user is created" do
  expect(chef_run).to create_user('web').with(
  	home: '/opt/jboss',
  	shell: '/bin/false',
  	)
end

it "check if group is created" do
expect(chef_run).to create_group('web')
end

it "should install PACKAGE via ark" do
    chef_run.should install_ark('jboss').with(
    	url: 'http://download.jboss.org/jbossas/7.1/jboss-as-7.1.1.Final/jboss-as-7.1.1.Final.tar.gz',
    	home_dir: '/opt/jboss',
  prefix_root:  '/opt',
  owner: 'web',
  version: '7.1.1.Final',
  )
  end

it "should check if template is created" do
  expect(chef_run).to create_template('/etc/init.d/jboss7').with(
  	mode: '0775',
  	owner: 'root',
  	)
  template = chef_run.template('/etc/init.d/jboss7')
  expect(template).to notify('service[jboss7]').to(:enable).delayed
  expect(template).to notify('service[jboss7]').to(:restart).delayed
end

it "should check service" do
expect(chef_run).to enable_service('jboss7')
#expect(chef_run).to restart_service('jboss7')
end
end



