control 'jboss7-user' do
	title 'check if jboss7-user and user is created'
	describe user('web') do
  		it { should exist }
  		its('home') { should eq '/opt/jboss' }
 		 its('shell') { should eq '/bin/false' }
  	end
  	describe group('web') do
  		it { should exist }
  	end
end

control 'jboss7-file' do
  impact 1.0
  title 'Check jboss7 config file owner, group and permissions.'
	describe file('/opt/jboss/standalone/configuration/standalone.xml') do
    	it { should be_owned_by 'web' }
    	it { should be_grouped_into 'web' }
    	its('mode') { should eq 00644 }
 	end
 	describe file('/opt/jboss/bin/standalone.conf') do
    	it { should be_owned_by 'web' }
    	it { should be_grouped_into 'web' }
    	its('mode') { should eq 00644 }
	end

	describe file('/etc/jboss-as.conf') do
    	it { should be_owned_by 'root' }
    	its('mode') { should eq 00775 }
	end
	describe file('/etc/init.d/jboss7') do
    	it { should be_owned_by 'root' }
    	its('mode') { should eq 00775 }
	end
end

control 'jboss7-service' do
  impact 1.0
  title 'jboss7 service'
	describe service('jboss7') do
  		it { should be_enabled }
  		it { should be_running }
	end
end