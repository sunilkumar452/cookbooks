# jnj_accseutil Cookbook

Description
===========

Cookbook is used to download the rpm package from s3 bucket and install it using
rpm_package resource. It installs accseutil and secutil packages.

Note
====
Used dvl for vpcxprefix.
For scm_deploy_rpm::install, we used rpm_resource.

Dependency
============

#/bin/ksh is a dependency for accseutil.

## Platforms

* Red Hat/CentOS/Scientific (6.0+ required) - "EL6-family"

Tested on:

* CentOS 7.2

Usage:
Chef-client run

## Cookbooks

None

Attributes
==========

The following attribute is set, see the `attributes/default.rb` file for values.

default['jnj_accseutil']['vpcxprefix']
default['jnj_accseutil']['downloadURL']
default['jnj_accseutil']['tmpaccutil']
default['jnj_accseutil']['tmpseutil']
default['jnj_accseutil']['pckgseutil']
default['jnj_accseutil']['pckgaccutil']


Recipes
=======

default
-------

License and Author
==================

- Author:: Shoaib (<mohd.shoaib@relevancelab.com>)
