default['jnj_accseutil']['vpcxprefix'] = 'dvl'
default['jnj_accseutil']['downloadURL'] = "https://s3.amazonaws.com/jnj-#{node['jnj_accseutil']['vpcxprefix']}-vpcx-scm/packages/jnj"

default['jnj_accseutil']['tmpaccutil'] = '/tmp/acctutil-1.1-1.noarch.rpm'
default['jnj_accseutil']['tmpseutil'] = '/tmp/secutil-2.8-1.noarch.rpm'

default['jnj_accseutil']['pckgseutil'] = 'secutil-2.8-1.noarch.rpm'
default['jnj_accseutil']['pckgaccutil'] = 'acctutil-1.1-1.noarch.rpm'
