#
# Cookbook Name:: jnj_accseutil
# Recipe:: default
#
# Copyright 2016, Relevance Lab
#
# All rights reserved - Do Not Redistribute
#

remote_file node['jnj_accseutil']['tmpaccutil'] do
  source "#{node['jnj_accseutil']['downloadURL']}/#{node['jnj_accseutil']['pckgaccutil']}"
  action :create
end

remote_file node['jnj_accseutil']['tmpseutil'] do
  source "#{node['jnj_accseutil']['downloadURL']}/#{node['jnj_accseutil']['pckgseutil']}"
  action :create
end

# Dependency for acctutil-1
package 'ksh' do
  action :install
end

rpm_package 'acctutil' do
  source node['jnj_accseutil']['tmpaccutil'].to_s
  action :install
end

rpm_package 'secutil' do
  source node['jnj_accseutil']['tmpseutil'].to_s
  action :install
end
