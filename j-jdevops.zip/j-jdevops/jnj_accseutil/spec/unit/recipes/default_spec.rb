#
# Cookbook Name:: jnj_accseutil
# Spec:: default
#
# Copyright (c) 2016 The Authors, All Rights Reserved.

require 'spec_helper'

describe 'jnj_accseutil::default' do
  context 'When all attributes are default, on an unspecified platform' do
    let(:chef_run) { ChefSpec::ServerRunner.new(platform: 'redhat', version: '7.0').converge(described_recipe) }

    it 'creates a remote_file with the default action' do
      expect(chef_run).to create_remote_file('/tmp/acctutil-1.1-1.noarch.rpm')
    end

    it 'creates a remote_file with the default action' do
      expect(chef_run).to create_remote_file('/tmp/secutil-2.8-1.noarch.rpm')
    end

    it 'install ksh Dependency for acctutil' do
      expect(chef_run).to install_package('ksh')
    end

    it 'installs rpm package' do
      expect(chef_run).to install_rpm_package('acctutil')
    end

    it 'installs rpm package secutil' do
      expect(chef_run).to install_rpm_package('secutil')
    end
  end
end
