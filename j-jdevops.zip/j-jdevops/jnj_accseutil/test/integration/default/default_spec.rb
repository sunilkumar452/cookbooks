
#
# describe file("/tmp/acctutil-1.1-1.noarch.rpm") do
#   it { should be_owned_by 'root' }
#   it { should be_grouped_into 'root' }
#   end
#
#  describe file("/tmp/secutil-2.8-1.noarch.rpm") do
#   it { should be_owned_by 'root' }
#   it { should be_grouped_into 'root' }
#   end

describe package('ksh') do
  it { should be_installed }
end

describe package('acctutil') do
  it { should be_installed }
end

describe package('secutil') do
  it { should be_installed }
end
