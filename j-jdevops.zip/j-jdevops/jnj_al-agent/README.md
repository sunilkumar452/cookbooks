# jnj_al-agent

Description
-----------

This Cookbook configures and installs al-agent service.

Requirements
------------

None

	The following platforms are tested directly under test kitchen.

	centos-6.7
	centos-7.2
	RHEL-7

Usage:
Chef-client run

Dependencies
------------

None


Attributes
----------

* `default['al_agents']['package']['apikey']`
* `default['al_agents']['package']['name']`
* `default['al_agents']['package']['base_url']`
* `default['al_agents']['agent']['al_agent_service']`
* `default['al_agents']['syslog_ng']['source_log']`
* `default['al_agents']['package']['url']`
* `default['al_agents']['windows_install_guard']`


Recipes
--------

default


License and Author
-----------------

**Author:** Sanchit Bansal (<sanchit.bansal@relevancelab.com>)
