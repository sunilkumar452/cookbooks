#
# Cookbook Name:: jnj_al-agent
# Recipe:: default
#
# Copyright (c) 2016 The Authors, All Rights Reserved.

execute 'getpackagesource' do
  cwd '/tmp/'
  command "wget #{node['al_agents']['package']['url']} -O al-agent"
end

package 'al-agent' do
  source '/tmp/al-agent'
  action :install
  version '>=0'
  provider Chef::Provider::Package::Dpkg if node['platform_family'] == 'debian'
  provider Chef::Provider::Package::Rpm if node['platform_family'] == 'rhel' && node['platform_version'].to_i >= 6
end
api_key = node['al_agents']['package']['apikey']
al_home_dir = '/var/alertlogic'
al_etc_dir = "#{al_home_dir}/etc"

if api_key =~ /^[a-zA-Z0-9]{50}$/
  execute 'Trigger AL agent api key update' do
    command "echo 'our Alert logic API key has changed'"
    only_if "bash -c 'al-agent print-config | grep host_uuid.*undefined'"
  end
  service 'al-agent' do
    action :stop
  end
  execute 'Delete all certs' do
    command "rm -rf #{al_etc_dir}/host*.pem"
  end
  execute 'Run AL configure' do
    command "/etc/init.d/al-agent configure --key #{api_key}"
  end
  service 'srrs_al_service' do
    service_name 'al-agent'
    action :nothing
    supports status: true, start: true, stop: true, restart: true
  end

  execute 'Run Al Provision' do
    command '/etc/init.d/al-agent provision --inst-type host'
    notifies :restart, 'service[srrs_al_service]', :immediately
  end
else
  execute 'invalid key' do
    command "echo 'invalid key'"
  end
end

service 'al-agent' do
  action :restart
end
