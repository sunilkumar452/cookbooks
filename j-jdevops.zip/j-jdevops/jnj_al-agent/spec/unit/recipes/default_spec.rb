#
# Cookbook Name:: jnj_al-agent
# Spec:: default
#
# Copyright (c) 2016 The Authors, All Rights Reserved.

require 'spec_helper'
describe 'jnj_al-agent::default' do
  let(:chef_run) do
    runner = ChefSpec::ServerRunner.new
    runner.converge(described_recipe)
  end

  let(:apikey) { '2196b8057024ef73037dba105cce5eea8c78c4c99a0ed23f29' }

  it 'should install PACKAGE al-agent' do
    stub_command("bash -c 'al-agent print-config | grep host_uuid.*undefined'").and_return(true)
    expect(chef_run).to install_package('al-agent')
  end

  it 'should install PACKAGE al-agent' do
    stub_command("bash -c 'al-agent print-config | grep host_uuid.*undefined'").and_return(true)
    expect(chef_run).to install_package('al-agent')
  end

  it 'Trigger AL agent api key update' do
    stub_command("bash -c 'al-agent print-config | grep host_uuid.*undefined'").and_return(true)
    expect(chef_run).to run_execute("echo 'our Alert logic API key has changed'")
  end

  it 'stop al-service' do
    stub_command("bash -c 'al-agent print-config | grep host_uuid.*undefined'").and_return(true)
    expect(chef_run).to stop_service('al-agent')
  end

  it 'Delete all certs' do
    stub_command("bash -c 'al-agent print-config | grep host_uuid.*undefined'").and_return(true)
    expect(chef_run).to run_execute('rm -rf /var/alertlogic/etc/host*.pem')
  end
  it 'Run AL configure' do
    stub_command("bash -c 'al-agent print-config | grep host_uuid.*undefined'").and_return(true)
    expect(chef_run).to run_execute("/etc/init.d/al-agent configure --key #{apikey}")
  end
  it 'Run Al Provision' do
    stub_command("bash -c 'al-agent print-config | grep host_uuid.*undefined'").and_return(true)
    serv = chef_run.execute('/etc/init.d/al-agent provision --inst-type host')
    expect(serv).to notify('service[srrs_al_service]').to(:restart).immediately
  end
  it 'start_al-service' do
    stub_command("bash -c 'al-agent print-config | grep host_uuid.*undefined'").and_return(true)
    expect(chef_run).to restart_service('al-agent')
  end
end
