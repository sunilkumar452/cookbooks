describe package('al-agent') do
  it { should be_installed }
end
describe service('al-agent') do
  it { should be_running }
end
