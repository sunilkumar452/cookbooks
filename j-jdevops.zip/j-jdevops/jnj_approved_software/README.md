# jnj_certificates Cookbook

Description
===========

Installs the list of packages in the node server

Requirements
============


## Platforms

* Red Hat/CentOS/Scientific (6.0+ required) - "EL6-family"

Tested on:

* CentOS 7.2

Usage:
Chef-client run

## Cookbooks

None

Attributes
==========

The following attribute is set ,see the `attributes/default.rb` file for default values.

['jnj_approved_software']['approved_soft']

Recipes
=======

default
-------

License and Author
==================

- Author:: Shoaib (<mohd.shoaib@relevancelab.com>)
