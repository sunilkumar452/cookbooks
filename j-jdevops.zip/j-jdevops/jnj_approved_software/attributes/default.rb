
default['jnj_approved_software']['approved_soft'] = %w(uuidd finger mailx ksh bind-utils)
