#
# Cookbook Name:: jnj_approved_software
# Recipe:: default
#
# Copyright (c) 2016 The Authors, All Rights Reserved.

(0..4).each do |pk|
  yum_package node['jnj_approved_software']['approved_soft'][pk]
end
