#
# Cookbook Name:: jnj_approved_software
# Spec:: default
#
# Copyright (c) 2016 The Authors, All Rights Reserved.

require 'spec_helper'
describe 'jnj_approved_software::default' do
  # describe 'When all attributes are default, on an unspecified platform' do
  let(:chef_run) { ChefSpec::ServerRunner.new.converge(described_recipe) }

  let(:pckglist) { %w(uuidd finger mailx ksh bind-utils) }

  it 'installs a yum_package with the default action' do
    pckglist.each do |pckg|
      expect(chef_run).to install_yum_package(pckg)
    end
  end
end
