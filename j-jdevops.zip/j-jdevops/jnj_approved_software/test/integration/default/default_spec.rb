
%w(uuidd finger mailx ksh bind-utils).each do |i|
  describe package(i) do
    it { should be_installed }
  end
end
