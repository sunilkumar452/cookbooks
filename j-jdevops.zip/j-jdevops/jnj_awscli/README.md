
# jnj_awscli Cookbook
=========================

Description
===========
TThis cookbook downloads awscli zip file and installs it.

Requirements
============

## Platforms

* Red Hat/CentOS/Scientific (6.0+ required) - "EL6-family"

Tested on:

* CentOS 7.2

Usage:
Chef-client run

## Cookbooks

None

Attributes
==========

default['jnj_awscli']['vpcxprefix'] 
default['jnj_awscli']['awscliversion'] 
default['jnj_awscli']['awsscr1'] 
default['jnj_awscli']['awsscr2'] 
default['jnj_awscli']['tmpdeleteaws'] 
default['jnj_awscli']['awsclidir'] 
default['jnj_awscli']['awsclizip'] 
default['jnj_awscli']['testcommand'] 

Recipes
=======

default
-------

License and Author
==================

- Author:: Shoaib <mohd.shoaib@relevancelab.com>


