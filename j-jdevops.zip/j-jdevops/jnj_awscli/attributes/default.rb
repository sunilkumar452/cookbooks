# Default attributes file
default['jnj_awscli']['vpcxprefix'] = 'dvl'
default['jnj_awscli']['awscliversion'] = '1.10.25'
default['jnj_awscli']['awsscr1'] = '/usr/local/aws'
default['jnj_awscli']['awsscr2'] = '/usr/local/bin/aws'
default['jnj_awscli']['tmpdeleteaws'] = '/tmp/awscli-bundle*'
default['jnj_awscli']['awsclidir'] = '/tmp/awscli-bundle'
default['jnj_awscli']['awsclizip'] = '/tmp/awscli-bundle.zip'

default['jnj_awscli']['testcommand'] = '/usr/local/bin/aws --version 2>&1 | grep -q 1.10.25'
