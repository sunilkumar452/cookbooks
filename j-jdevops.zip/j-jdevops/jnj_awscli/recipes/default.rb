#
# Cookbook Name:: jnj_awscli
# Recipe:: default
#
# Copyright 2016, YOUR_COMPANY_NAME
#
# All rights reserved - Do Not Redistribute
#
# include_recipe "jnj_awscli::awscli"

package 'unzip' do
  action :install
end

testcommand = "test -x /usr/local/bin/aws && /usr/local/bin/aws --version 2>&1 | grep -q #{node['jnj_awscli']['awscliversion']}"

execute 'rm' do
  command "rm -rf #{node['jnj_awscli']['tmpdeleteaws']}"
  cwd '/tmp/'
  not_if testcommand.to_s
  ignore_failure true
end

# Remove old aws scripts
directory 'delete_aws_dir' do
  path node['jnj_awscli']['awsscr1']
  action :delete
  recursive true
  not_if testcommand.to_s
  ignore_failure true
end

file 'delete_aws_script2' do
  path node['jnj_awscli']['awsscr2']
  action :delete
  not_if testcommand.to_s
  ignore_failure true
end

remote_file node['jnj_awscli']['awsclizip'] do
  source "https://s3.amazonaws.com/jnj-#{node['jnj_awscli']['vpcxprefix']}-vpcx-scm/bootstrap/awscli-bundle-#{node['jnj_awscli']['awscliversion']}.zip"
  not_if { ::File.exist?((node['jnj_awscli']['awsclizip']).to_s) }
  not_if testcommand.to_s
end

execute 'unzip file' do
  cwd '/tmp'
  command "unzip #{node['jnj_awscli']['awsclizip']}"
  only_if "test -f #{node['jnj_awscli']['awsclizip']}"
end

directory (node['jnj_awscli']['awsclidir']).to_s do
  mode '0775'
  recursive true
end

# execute 'actual install' do
#   command "#{node['jnj_awscli']['awsclidir']}/install -i /usr/local/aws -b /usr/local/bin/aws"
#   only_if { ::File.exist?("#{node['jnj_awscli']['awsclidir']}/install") }
#   not_if "#{testcommand}"
# end

execute 'actual install' do
  command "#{node['jnj_awscli']['awsclidir']}/install -i /usr/local/aws -b /usr/local/bin/aws"
  only_if "test -x #{node['jnj_awscli']['awsclidir']}/install"
  not_if testcommand.to_s
end

execute 'rm' do
  command "rm -rf #{node['jnj_awscli']['tmpdeleteaws']}"
  cwd '/tmp/'
  ignore_failure true
end
