require 'spec_helper'
describe 'jnj_awscli::default' do
  context 'When all attributes are default, on an unspecified platform' do
    let(:chef_run) do
      runner = ChefSpec::ServerRunner.new
      runner.converge(described_recipe)
    end

    it 'converges successfully' do
      stub_command('test -x /tmp/awscli-bundle/install').and_return(true)
      stub_command('test -x /usr/local/bin/aws && /usr/local/bin/aws --version 2>&1 | grep -q 1.10.25').and_return(false)
      stub_command('test -f /tmp/awscli-bundle.zip').and_return(true)
      expect(chef_run).to install_package('unzip')
      expect(chef_run).to run_execute('rm -rf /tmp/awscli-bundle*')
      expect(chef_run).to delete_directory('/usr/local/aws')
      expect(chef_run).to delete_file('/usr/local/bin/aws')
      expect(chef_run).to create_remote_file('/tmp/awscli-bundle.zip')
    end

    it 'unzips' do
      stub_command('test -x /tmp/awscli-bundle/install').and_return(true)
      stub_command('test -f /tmp/awscli-bundle.zip').and_return(true)
      stub_command('test -x /usr/local/bin/aws && /usr/local/bin/aws --version 2>&1 | grep -q 1.10.25').and_return(false)
      expect(chef_run).to run_execute('unzip /tmp/awscli-bundle.zip').with_cwd('/tmp')
      expect(chef_run).to run_execute('/tmp/awscli-bundle/install -i /usr/local/aws -b /usr/local/bin/aws')
      expect(chef_run).to run_execute('rm -rf /tmp/awscli-bundle*')
    end
  end
end
