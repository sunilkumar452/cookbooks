
describe package('unzip') do
  it { should be_installed }
end

describe file('/usr/local/bin/aws') do
  it { should be_present }
end

describe file('/usr/local/aws') do
  it { should be_directory }
end
