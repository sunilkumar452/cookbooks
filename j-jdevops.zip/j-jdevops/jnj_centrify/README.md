# centrify


This Cookbook add server to LDAP and joins jnj domain. Can only be tested in Jnj Network.

Requirements

	Testes on RHEL-7 with already executed Puppet Manifest in JnJ Network.

Attributes

    Values to download domain joining script based on region: 
		default['its_core']['AP']['dmlloc'] = 'http://itsusrasmtp1.jnj.com/sw/dml/RHEL6/6.3.00'
		default['its_core']['EU']['dmlloc'] = 'http://itsbebesmtp1.eu.jnj.com/sw/dml/RHEL6/6.3.00'
		default['its_core']['LA']['dmlloc'] = 'http://itsusrasmtp1.jnj.com/sw/dml/RHEL6/6.3.00'
		default['its_core']['NA']['dmlloc'] = 'http://itsusrasmtp1.jnj.com/sw/dml/RHEL6/6.3.00'
	
	Below is booleas to agree whether server needs to be joined in domain or not
		default['its_core']['centrify_needs_join'] = 'yes'

Testing

	In the root of the project:
	  To execute test kitchen: kitchen test
