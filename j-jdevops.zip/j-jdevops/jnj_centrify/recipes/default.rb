#
# Cookbook Name:: centrify
# Recipe:: default
#
# Copyright (c) 2016 The Authors, All Rights Reserved.
  
  needs_join = node['its_core']['centrify_needs_join']
  hostname = node["hostname"]
  #hostname = "aws031nva1138"

ruby_block 'region check' do
  block do
  region = hostname.match(/^(...)(...)(...)(\d+$)/)[3]   
  scm_account = hostname.match(/^(...)(...)(...)(\d+$)/)[2]
  if "#{region}" == 'NVA' or "#{region}" == 'nva'
      set_region = 'NA' 
  elsif "#{region}" == 'IRL' or "#{region}" == 'irl'
      set_region = 'EU' 	  
  elsif "#{region}" == 'AMS' or "#{region}" == 'ams'
      set_region = 'EU' 
  elsif "#{region}" == 'SGP' or "#{region}" == 'sgp'
      set_region = 'AP'
  end
  set_region = 'NA'
  dmlloc = node['its_core']["#{set_region}"]['dmlloc']
  if node['ipaddress'] =~ /^10\.0\./
    joinscript = "#{dmlloc}/jnj_adjoin.sh-lab"
    domain = 'dfdev.jnj.com'
    zone = 'ITS_NONPROD_LINUX'
  elsif "itx-#{scm_account}" == "itx-008" and "#{scm_tag_staging_ad}" != "" or "#{aws_tag_staging_ad}" != ""
    #and ($::scm_tag_staging_ad != undef or $::aws_tag_staging_ad != undef) ) {
    joinscript = "https://s3.amazonaws.com/jnj-dvl-vpcx-scm/bootstrap/jnj_adjoin.sh-staging"
    domain = 'sjnj.com'
    uphostname = upcase("#{hostname}")
    zone = "#{uphostname}-LINUX-#{set_region}"
  else 
    joinscript = "#{dmlloc}/jnj_adjoin.sh"
    domain = 'jnj.com'
    uphostname = upcase("#{hostname}")
    zone = "#{uphostname}-LINUX-#{set_region}"
  end
  end
end

  rpm_package "CentrifyDC" do
    source "https://s3.amazonaws.com/jnj-vpcx-scm/packages/centrify/centrifydc-5.2.1-rhel3-x86_64.rpm"
    action :install
  end

  cookbook_file '/etc/centrifydc/centrifydc.conf' do
    owner 'root'
    group 'root'
    mode  0644
    source "centrifydc-5.2.1.conf"
    #require => Package['CentrifyDC'],
    #notifies service["centrifydc"]
  end

  #"#{centrify_mode}" == '' and

  if "#{needs_join}" != 'NO'
  #notify {"need join":}
  execute 'do_join' do
    command "/usr/bin/curl  #{'joinscript'} > /root/jnj_adjoin.sh \
                && /bin/bash /root/jnj_adjoin.sh -z $zone -d $domain \
                && /usr/bin/adinfo -m \
                && mv /etc/pam.d/password-idm-auth /etc/pam.d/password-idm-auth.pre_cdc \
                && grep '^account.*centrify' /etc/pam.d/password-auth-ac.cdc > /etc/pam.d/password-idm-auth \
                && cat /etc/pam.d/password-idm-auth.pre_cdc >> /etc/pam.d/password-idm-auth"
      only_if do ::File.exists?('/etc/centrifydc/centrifydc.conf') end
    end     
  end

  #"#{centrify_mode}" != '' and  
   
  if "#{needs_join}" == 'NO'
    #notify {"need unjoin":}
    execute "do_unjoin" do
      command "/usr/sbin/adleave -f"
    end
  end
  
   
  if "#{needs_join}" != 'NO'
    service "centrifydc" do
      action [:enable, :start]
	end
  else
    service "centrifydc" do
      action :stop
	end
  end 	

  # stop and disable 'abrt' services
  service 'abrt-ccpp' do
    action :stop
  end
  service 'abrt-oops' do
    action :stop
  end
  service 'abrtd' do
    action :stop
  end
