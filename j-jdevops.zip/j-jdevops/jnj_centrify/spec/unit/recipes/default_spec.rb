#
# Cookbook Name:: centrify
# Spec:: default
#
# Copyright (c) 2016 The Authors, All Rights Reserved.

require 'spec_helper'

describe 'jnj_centrify::default' do
  context 'When all attributes are default, on an unspecified platform' do
    let(:chef_run) do
      runner = ChefSpec::ServerRunner.new(platform: 'ubuntu', version: '14.04')
      runner.converge(described_recipe)
    end

    it 'converges successfully' do
      expect { chef_run }.to_not raise_error
    end

    it 'install rpm' do
      expect(chef_run).to install_rpm_package("CentrifyDC").with(
        source: 'https://s3.amazonaws.com/jnj-vpcx-scm/packages/centrify/centrifydc-5.2.1-rhel3-x86_64.rpm')
    end
  
    it 'creates a cookbook_file' do
      expect(chef_run).to create_cookbook_file('/etc/centrifydc/centrifydc.conf')
    end
    needs_join = 'yes'
    hostname = 'aws031nva1138'
    region = '#{hostname}.match(/^(...)(...)(...)(\d+$)/)[3]'
    $scm_account = '#{hostname}.match(/^(...)(...)(...)(\d+$)/)[2]'

    if  "#{region}" == 'NVA' or "#{region}" == 'nva'
      @set_region = 'NA' 
  elsif "#{region}" == 'IRL' or "#{region}" == 'irl'
      @set_region = 'EU'     
  elsif "#{region}" == 'AMS' or "#{region}" == 'ams'
      @set_region = 'EU' 
  elsif "#{region}" == 'SGP' or "#{region}" == 'sgp'
      @set_region = 'AP'
  end
  dmlloc = '#{set_region}'
  class Sujith
    $joinscript
def test
  if @ipaddress =~ /^10\.0\./
    joinscript = "dmlloc/jnj_adjoin.sh-lab"
    domain = "dfdev.jnj.com"
    zone = "ITS_NONPROD_LINUX"
    elsif "@itx-#{$scm_account}" == "itx-008" && "scm_tag_staging_ad" != "" || "aws_tag_staging_ad" != ""
     joinscript = "https://s3.amazonaws.com/jnj-dvl-vpcx-scm/bootstrap/jnj_adjoin.sh-staging"
     domain = "sjnj.com"
     zone = "uphostname-LINUX-set_region"
   else
    joinscript = "dmlloc/jnj_adjoin.sh-lab"
        domain = "jnj.com"
    zone = "#{uphostname}-LINUX-#{set_region}"
  end
  return joinscript
  var = test
  puts var
end
end
  @obj = Sujith.new
  @obj.test
    # it 'centrifydc' do
    #   expect(chef_run).to install_rpm_package('https://s3.amazonaws.com/jnj-vpcx-scm/packages/centrify/centrifydc-5.2.1-rhel3-x86_64.rpm')
    # end
    # it 'creates a cookbook_file' do
    #   expect(chef_run).to create_cookbook_file('/tmp/config').with_user(
    #     owner: 'root',
    #     group: 'root',
    #     mode:   '0644'
    #     )
    #   end
      if $needs_join == 'NO'
      it 'execute command' do
        expect(chef_run).to run_execute('/usr/bin/curl  dmlloc/var> /root/jnj_adjoin.sh \ && /bin/bash /root/jnj_adjoin.sh -z $zone -d $domain \ && /usr/bin/adinfo -m \&& mv /etc/pam.d/password-idm-auth /etc/pam.d/password-idm-auth.pre_cdc \&& grep ^account.*centrify /etc/pam.d/password-auth-ac.cdc > /etc/pam.d/password-idm-auth \ && cat /etc/pam.d/password-idm-auth.pre_cdc >> /etc/pam.d/password-idm-auth')
      end
    

      it 'do_unjoin' do
        expect(chef_run).to run_execute('/usr/sbin/adleave -f')
      end
      it 'centrifydc' do
        expect(chef_run).to enable_service('centrifydc')
        expect(chef_run).to start_service('centrifydc')
        expect(chef_run).to stop_service('centrifydc')
      end
      end
     it 'stop service' do
      expect(chef_run).to stop_service('abrt-ccpp')
    end
    it 'stop service' do
      expect(chef_run).to stop_service('abrt-oops')
    end
    it 'stop service' do
      expect(chef_run).to stop_service('abrtd')
    end
    end
  end
