describe file('/etc/centrifydc/centrifydc.conf') do
  it { should be_file }
end

describe file('/etc/centrifydc/user.ignore') do
  it { should be_file }
end
describe service('centrifydc') do
  it { should be_running }
end