# jnj_certificates Cookbook

Description
===========

Cookbook is used to install jnj certificates and to make sure old certificates are absent.

Requirements
============

#Java should be installed for install_java_certificates to work

## Platforms

* Red Hat/CentOS/Scientific (6.0+ required) - "EL6-family"

Tested on:

* CentOS 7.2

Usage:
Chef-client run

## Cookbooks

None

Attributes
==========

The following attribute is set ,see the `attributes/default.rb` file for default values.

default[:jnj_certificate][:cert_dir]
default[:jnj_certificate][:install_script]
default[:jnj_certificate][:certname] 
default[:jnj_certificate][:file_path] 
default[:jnj_certificate][:mode] 
default[:jnj_certificate][:file_remove] 


Recipes
=======

default
-------

License and Author
==================

- Author:: Praneeta Kumari (<praneeta.kumari@relevancelab.com>)

