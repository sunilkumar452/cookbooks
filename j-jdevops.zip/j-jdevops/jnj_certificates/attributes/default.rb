default['jnj_certificate']['cert_dir'] = '/etc/pki/tls/certs'
default['jnj_certificate']['install_script'] = '/etc/pki/tls/certs/install_jnj-certs.sh'
default['jnj_certificate']['script_source'] = 'install_jnj-certs.sh'
default['jnj_certificate']['certname'] = %w(INT-PROD-CA-A2.pem INT-PROD-CA-B2.pem INT-PROD-CA-C2.pem INT-PROD-Root.pem
                                            polca2048bit.pem rootca2048bit.pem Entrust-CA.pem Entrust-Root.pem)
default['jnj_certificate']['file_path'] = %w(/etc/pki/tls/certs/INT-PROD-CA-A2.pem /etc/pki/tls/certs/INT-PROD-CA-B2.pem /etc/pki/tls/certs/INT-PROD-CA-C2.pem /etc/pki/tls/certs/INT-PROD-Root.pem /etc/pki/tls/certs/polca2048bit.pem /etc/pki/tls/certs/rootca2048bit.pem /etc/pki/tls/certs/Entrust-CA.pem /etc/pki/tls/certs/Entrust-Root.pem)
default['jnj_certificate']['mode'] = '0644'
default['jnj_certificate']['file_remove'] = %w(INT-PROD-CA-A.pem  f5203f42.0 INT-PROD-CA-B.pem 33ac1b72.0)
