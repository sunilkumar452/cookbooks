#!/bin/bash
################################################################################################
###
### Description: Script is used to install the J&J Certs. Script is called from
###              the puppet mmodule; certificates.pp
###     Author : Chris Aucone 
###       Date : 3/12/2014
###    Version : 1.0 
###
################################################################################################

# Cert name is passed from the puppet module.
cert_name="$1"

cd /etc/pki/tls/certs

# Link the cert to a hash name 
/bin/ln -s "$cert_name" `/usr/bin/openssl x509 -hash -noout -in "$cert_name"`.0

# Add the cert to the cert database
name=$(/usr/bin/openssl x509 -in "$cert_name" -subject -noout | /bin/sed "s/.*CN=//")
/usr/bin/certutil -A -d sql:/etc/pki/nssdb -t "C,C,C" -n "${name}" -i "$cert_name"

# Verify that the cert was installed
# If the cert expired it will write a message to the messages file.
hash_num=$(/bin/ls -l /etc/pki/tls/certs/*.0 | /bin/grep $cert_name | /bin/awk '{print $9}')

echo "$(/usr/bin/openssl x509 -in $hash_num -subject -noout | /bin/sed 's/.*CN=//')";\
/usr/bin/openssl verify -verbose $hash_num |\
/bin/grep "expired" && /usr/bin/logger -t CERT_EXPIRED "Certificate $(/usr/bin/openssl x509 -in $hash_num -subject -noout | /bin/sed 's/.*CN=//') expired..."\
 || exit 0

