#
# Cookbook Name'' jnj_certificates
# Recipe'' default
#
# Copyright 2016, Relevance Labs
#
# All rights reserved - Do Not Redistribute
#

cookbook_file node['jnj_certificate']['install_script'] do
  owner 'root'
  group 'root'
  mode 0755
  source node['jnj_certificate']['script_source']
  sensitive true
  not_if { File.exist?((node['jnj_certificate']['install_script']).to_s) }
end

(0..7).each do |i|
  cookbook_file node['jnj_certificate']['file_path'][i] do
    owner 'root'
    group 'root'
    mode node['jnj_certificate']['mode']
    source node['jnj_certificate']['certname'][i]
    sensitive true
  end
end

(0..7).each do |i|
  execute "install_certificates_#{i}" do
    command "#{node['jnj_certificate']['install_script']} #{node['jnj_certificate']['certname'][i]}"
    not_if  "/bin/ls -l #{node['jnj_certificate']['cert_dir']}/*.0 | /bin/grep -c #{node['jnj_certificate']['certname'][i]}"
  end
end

(0..7).each do |i|
  execute "install_java_certificates_#{i}" do
    command "/usr/bin/keytool -importcert -keystore /etc/pki/java/cacerts -storepass changeit -file #{node['jnj_certificate']['cert_dir']}/#{node['jnj_certificate']['certname'][i]} -noprompt -alias jnj_#{node['jnj_certificate']['certname'][i]}"
    only_if "/usr/bin/test -x /usr/bin/keytool;/usr/bin/keytool -list -keystore /etc/pki/java/cacerts -storepass changeit -alias jnj_#{node['jnj_certificate']['certname'][i]} | grep -i keytool.error"
  end
end

node['jnj_certificate']['file_remove'].each do |k|
  file "#{node['jnj_certificate']['cert_dir']}/#{k}" do
    action :delete
    only_if "ls -l #{node['jnj_certificate']['cert_dir']}/#{k}"
  end
end
