#
# Cookbook Name:: jnj_certicates
# Spec:: default
#
# Copyright (c) 2016 The Authors, All Rights Reserved.

require 'chefspec'
require 'spec_helper'

describe 'jnj_certificates::default' do
  let(:chef_run) { ChefSpec::SoloRunner.new.converge(described_recipe) }

  it 'checks if file is present' do
    ['INT-PROD-CA-A2.pem', 'INT-PROD-CA-B2.pem', 'INT-PROD-CA-C2.pem', 'INT-PROD-Root.pem',
     'polca2048bit.pem', 'rootca2048bit.pem', 'Entrust-CA.pem', 'Entrust-Root.pem'].each do |i|
      stub_command("/bin/ls -l /etc/pki/tls/certs/*.0 | /bin/grep -c #{i}").and_return(false)
      stub_command("/usr/bin/test -x /usr/bin/keytool;/usr/bin/keytool -list -keystore /etc/pki/java/cacerts -storepass changeit -alias jnj_#{i} | grep -i keytool.error").and_return(true)
    end

    ['INT-PROD-CA-A.pem', 'f5203f42.0', 'INT-PROD-CA-B.pem', '33ac1b72.0'].each do |s|
      stub_command("ls -l /etc/pki/tls/certs/#{s}").and_return(true)
    end

    expect(chef_run).to create_cookbook_file('/etc/pki/tls/certs/install_jnj-certs.sh').with(
      owner: 'root',
      group: 'root',
      mode: 0755
    )

    ['/etc/pki/tls/certs/INT-PROD-CA-A2.pem', '/etc/pki/tls/certs/INT-PROD-CA-B2.pem', '/etc/pki/tls/certs/INT-PROD-CA-C2.pem', '/etc/pki/tls/certs/INT-PROD-Root.pem', '/etc/pki/tls/certs/polca2048bit.pem', '/etc/pki/tls/certs/rootca2048bit.pem', '/etc/pki/tls/certs/Entrust-CA.pem', '/etc/pki/tls/certs/Entrust-Root.pem'].each do |i|
      expect(chef_run).to create_cookbook_file(i).with(
        owner: 'root',
        group: 'root',
        mode: '0644'
      )
    end
  end
end

describe 'jnj_certificates::default' do
  let(:chef_run) { ChefSpec::SoloRunner.new.converge(described_recipe) }

  it 'checks certs and file' do
    ['INT-PROD-CA-A2.pem', 'INT-PROD-CA-B2.pem', 'INT-PROD-CA-C2.pem', 'INT-PROD-Root.pem', 'polca2048bit.pem', 'rootca2048bit.pem', 'Entrust-CA.pem', 'Entrust-Root.pem'].each do |i|
      stub_command("/bin/ls -l /etc/pki/tls/certs/*.0 | /bin/grep -c #{i}").and_return(false)
      stub_command("/usr/bin/test -x /usr/bin/keytool;/usr/bin/keytool -list -keystore /etc/pki/java/cacerts -storepass changeit -alias jnj_#{i} | grep -i keytool.error").and_return(true)
    end

    ['INT-PROD-CA-A.pem', 'f5203f42.0', 'INT-PROD-CA-B.pem', '33ac1b72.0'].each do |s|
      stub_command("ls -l /etc/pki/tls/certs/#{s}").and_return(true)
    end

    ['INT-PROD-CA-A2.pem', 'INT-PROD-CA-B2.pem', 'INT-PROD-CA-C2.pem', 'INT-PROD-Root.pem', 'polca2048bit.pem', 'rootca2048bit.pem', 'Entrust-CA.pem', 'Entrust-Root.pem'].each do |p|
      expect(chef_run).to run_execute("/etc/pki/tls/certs/install_jnj-certs.sh #{p}")
    end
    ['INT-PROD-CA-A2.pem', 'INT-PROD-CA-B2.pem', 'INT-PROD-CA-C2.pem', 'INT-PROD-Root.pem', 'polca2048bit.pem', 'rootca2048bit.pem', 'Entrust-CA.pem', 'Entrust-Root.pem'].each do |q|
      expect(chef_run).to run_execute("/usr/bin/keytool -importcert -keystore /etc/pki/java/cacerts -storepass changeit -file /etc/pki/tls/certs/#{q} -noprompt -alias jnj_#{q}")
    end

    ['INT-PROD-CA-A.pem', 'f5203f42.0', 'INT-PROD-CA-B.pem', '33ac1b72.0'].each do |k|
      expect(chef_run).to delete_file("/etc/pki/tls/certs/#{k}")
    end
  end
end
