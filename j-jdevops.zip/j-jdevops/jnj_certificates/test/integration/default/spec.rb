describe file('/etc/pki/tls/certs/install_jnj-certs.sh') do
  it { should exist }
  it { should be_owned_by 'root' }
  it { should be_grouped_into 'root' }
  its('mode') { should eq 00755 }
end

['/etc/pki/tls/certs/INT-PROD-CA-A2.pem', '/etc/pki/tls/certs/INT-PROD-CA-B2.pem', '/etc/pki/tls/certs/INT-PROD-CA-C2.pem', '/etc/pki/tls/certs/INT-PROD-Root.pem', '/etc/pki/tls/certs/polca2048bit.pem', '/etc/pki/tls/certs/rootca2048bit.pem', '/etc/pki/tls/certs/Entrust-CA.pem', '/etc/pki/tls/certs/Entrust-Root.pem'].each do |i|
  describe file(i) do
    it { should exist }
    it { should be_owned_by 'root' }
    it { should be_grouped_into 'root' }
    its('mode') { should eq 00644 }
  end
end

['INT-PROD-CA-A2.pem', 'INT-PROD-CA-B2.pem', 'INT-PROD-CA-C2.pem', 'INT-PROD-Root.pem', 'polca2048bit.pem', 'rootca2048bit.pem', 'Entrust-CA.pem', 'Entrust-Root.pem'].each do |i|
  describe command("/etc/pki/tls/certs/install_jnj-certs.sh #{i}") do
    its('exit_status') { should eq 0 }
  end
end

['INT-PROD-CA-A2.pem', 'INT-PROD-CA-B2.pem', 'INT-PROD-CA-C2.pem', 'INT-PROD-Root.pem', 'polca2048bit.pem', 'rootca2048bit.pem', 'Entrust-CA.pem', 'Entrust-Root.pem'].each do |i|
  describe command("/usr/bin/keytool -list -keystore /etc/pki/java/cacerts -storepass changeit -alias  jnj_#{i}") do
    its('exit_status') { should eq 0 }
  end
end

['INT-PROD-CA-A.pem', 'f5203f42.0', 'INT-PROD-CA-B.pem', '33ac1b72.0'].each do |i|
  describe file i do
    it { should_not exist }
  end
end
