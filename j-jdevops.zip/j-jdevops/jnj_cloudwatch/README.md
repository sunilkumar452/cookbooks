# jnj_cloudwatch Cookbook

Description
===========

Cookbook for cloudwatch.Includes J&J written script to execute AWS's cloud watches scripts.

Requirements
============

## Platforms

* Red Hat/CentOS/Scientific (6.0+ required) - "EL6-family"

Tested on:

* CentOS 6.7, 7.2

Usage:
Chef-client run

## Cookbooks

None

Attributes
==========

The following attribute is set ,see the `attributes/default.rb` file for default values.

default[:jnj_cloudwatch][:pkg] = Packages to be installed
default[:jnj_cloudwatch][:dir] =  Cloudwatch directory
default[:jnj_cloudwatch][:file_path]  = File path
default[:jnj_cloudwatch][:source] = File source
default[:jnj_cloudwatch][:mode] =  File mode


Recipes
=======

default
-------

License and Author
==================

- Author:: Praneeta Kumari (<praneeta.kumari@relevancelab.com>)

