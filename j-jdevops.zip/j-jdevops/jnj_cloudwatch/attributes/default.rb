default[:jnj_cloudwatch][:pkg] = ['perl-Crypt-SSLeay', 'perl-Switch' ,'perl-Sys-Syslog' ,'perl-Digest-SHA' ,'perl-URI' ,'perl-IO-Compress' ,'perl-libwww-perl','perl-LWP-Protocol-https']
default[:jnj_cloudwatch][:dir] = '/opt/cloudwatch'
default[:jnj_cloudwatch][:file_path] = %w{/opt/cloudwatch/CW_FS_MEM_monitor.sh /opt/cloudwatch/CloudWatchClient.pm 
	                                      /opt/cloudwatch/LICENSE.txt /opt/cloudwatch/mon-get-instance-stats.pl 
	                                      /opt/cloudwatch/mon-put-instance-data.pl /opt/cloudwatch/NOTICE.txt /etc/cron.d/cloudwatch_monitoring}
default[:jnj_cloudwatch][:mode] = [ '0655', '0644', '0644', '0755', '0755', '0644', '0644' ]
default[:jnj_cloudwatch][:source] = %w{CW_FS_MEM_monitor.sh CloudWatchClient.pm LICENSE.txt mon-get-instance-stats.pl
                                        mon-put-instance-data.pl NOTICE.txt cloudwatch_monitoring}