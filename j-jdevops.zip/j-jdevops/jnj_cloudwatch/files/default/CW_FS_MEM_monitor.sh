#!/bin/bash
#################################################################################################################
####   Scriptname: CW_FS_MEM_monitor.sh
####      Version: 1.0
####  Description: Script will execute cloudwatch monitors for filesystems, memory and swap.
####               The data will also be sent AWS for reporting. 
####       Author: Chris Aucone
####         Date: 28-Feb-2014
#################################################################################################################

# sleep a random time but fixed per server to prevent that all servers hit xbot console at the same time
sleep $(( $(/sbin/ip a s eth0 | /bin/sed -n "/ inet /s#.*inet [^.]*.\([^.]*\).\([^.]*\).\([^.]*\)/.*#\1\2\3#p") % 257 ))

## Define the variables
cloudwatch_dir="/opt/cloudwatch"
awscreds="awscreds.conf"

## get vpcxprefix
source /etc/vpcxprefix.txt

## Define Functions
function get_creds {
  curl -sS http://${vpcxprefix}console.vpcx.jnj.com/account/metric-reporter > /opt/cloudwatch/metric-reporter
  AccessKey=`strings $cloudwatch_dir/metric-reporter | grep AWSAccessKeyId |cut -d "=" -f2`
  SecKey=`strings $cloudwatch_dir/metric-reporter | grep AWSSecretKey  |cut -d "=" -f2`
  echo "AWSAccessKeyId=$AccessKey" > $cloudwatch_dir/$awscreds
  echo "AWSSecretKey=$SecKey" >> $cloudwatch_dir/$awscreds
  /bin/rm -f /opt/cloudwatch/metric-reporter*
}

## Check if the awscreds file exists
if [ -f /opt/cloudwatch/awscreds.conf ]
 then
  $cloudwatch_dir/mon-put-instance-data.pl --aws-credential-file=$cloudwatch_dir/$awscreds --disk-space-util --disk-path=/ --from-cron
  verify_RC=$?
     if [ $verify_RC != 0 ]
       then
        get_creds
     fi 
 else
  get_creds
fi
