#
# Cookbook Name jnj_cloudwatch
# Recipe default
#
# Copyright 2016, Relevance Lab Pvt LTD, Inc.
#
# All rights reserved - Do Not Redistribute
#


# Ensure the /opt/cloudwatch directory exists.
 directory node[:jnj_cloudwatch][:dir] do
    owner 'root'
    group 'root'
    mode   0755
  end

(0..6).each do |i| 
    cookbook_file node[:jnj_cloudwatch][:file_path][i] do
        owner 'root'
        group 'root'
        mode node[:jnj_cloudwatch][:mode][i]
        source node[:jnj_cloudwatch][:source][i]
        sensitive true
    end
end


if node['platform_version'].to_i == 6.0

# Package is required for cloudwatch to be able to post the data to AWS
    package  'perl-Crypt-SSLeay'   

    else
    node[:jnj_cloudwatch][:pkg].each do |pkg|
        package pkg do
            action :install
        end 
end
 
 end 
