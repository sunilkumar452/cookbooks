require 'chef'

describe directory("/opt/cloudwatch") do
  it { should be_owned_by 'root' }
  it { should be_grouped_into 'root' }
  its('mode') { should eq 00755 }
  end

describe file("/opt/cloudwatch/CW_FS_MEM_monitor.sh") do
  it { should be_owned_by 'root' }
  it { should be_grouped_into 'root' }
  its('mode') { should eq 00655 }
 end

describe file("/opt/cloudwatch/CloudWatchClient.pm") do
  it { should be_owned_by 'root' }
  it { should be_grouped_into 'root' }
  its('mode') { should eq 00644 }
end

describe file("/opt/cloudwatch/LICENSE.txt") do
  it { should be_owned_by 'root' }
  it { should be_grouped_into 'root' }
  its('mode') { should eq 00644 }
end


describe file("/opt/cloudwatch/mon-get-instance-stats.pl") do
  it { should be_owned_by 'root' }
  it { should be_grouped_into 'root' }
  its('mode') { should eq 00755 }
end

describe file("/opt/cloudwatch/mon-put-instance-data.pl") do
  it { should be_owned_by 'root' }
  it { should be_grouped_into 'root' }
  its('mode') { should eq 00755 }
end

describe file("/opt/cloudwatch/NOTICE.txt") do
  it { should be_owned_by 'root' }
  it { should be_grouped_into 'root' }
  its('mode') { should eq 00644 }
end


describe file("/etc/cron.d/cloudwatch_monitoring") do
  it { should be_owned_by 'root' }
  it { should be_grouped_into 'root' }
  its('mode') { should eq 00644 }
end

 
 s = os[:release] 

 if s.to_i == 6
      describe package ('perl-Crypt-SSLeay') do   
      Chef::Log.warn('In ..'+s)
      it { should be_installed }
      
      end
      else
    # end

  ['perl-Crypt-SSLeay', 'perl-Switch' ,'perl-Sys-Syslog' ,'perl-Digest-SHA' ,'perl-URI' ,'perl-IO-Compress' ,'perl-libwww-perl','perl-LWP-Protocol-https'].each do |pkg|
    describe package (pkg) do
	  it { should be_installed }
   end
 end
end










