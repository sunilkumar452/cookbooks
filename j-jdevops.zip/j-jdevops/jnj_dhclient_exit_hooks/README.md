# dhclient_exit_hooks


This Cookbook configures dhclient_exit_hooks.

Requirements

	The following platforms are tested directly under test kitchen.

	centos-6.7
	centos-7.2
	RHEL-7


Testing

	In the root of the project:
	  To execute test kitchen: kitchen test

