#
# Cookbook Name:: dhclient_exit_hooks
# Spec:: default
#
# Copyright (c) 2016 The Authors, All Rights Reserved.

#require 'spec_helper'
require 'chefspec'

describe 'dhclient_exit_hooks::default' do
  context 'When all attributes are default, on an unspecified platform' do
    let(:chef_run) do
      runner = ChefSpec::ServerRunner.new
      runner.converge(described_recipe)
    end

    it 'converges successfully' do
      expect { chef_run }.to_not raise_error
    end
    it 'creates a file /etc/dhcp/dhclient-exit-hooks' do
      expect(chef_run).to create_cookbook_file('/etc/dhcp/dhclient-exit-hooks')
    end

    it 'creates a file with attributes' do
      expect(chef_run).to create_cookbook_file('/etc/dhcp/dhclient-exit-hooks').with(
         user:   'root',
         group:  'root',
         mode:  '0755'
      )
    end
  it 'runs a execute reread_dhclient' do
    expect(chef_run).to run_execute('/sbin/dhclient-script MEDIUM')
  end
  end
end
