# jnj_etcpasswd_nologin Cookbook

Description


Cookbook is used to enforce nologin on daemon accounts

Requirements


## Platforms

* Red Hat/CentOS/Scientific (6.0+ required) - "EL6-family"

Tested on:

* CentOS 6.7, 7.2

Usage:
Chef-client run

## Cookbooks

None

Attributes


The following attribute is set ,see the `attributes/default.rb` file for default values.

default[:jnj_etcpasswd][:user] 
default[:jnj_etcpasswd][:uid]   
default[:jnj_etcpasswd][:gid]   
default[:jnj_etcpasswd][:comment] 
default[:jnj_etcpasswd][:shell]  
default[:jnj_etcpasswd][:home]  
default[:jnj_etcpasswd][:user1]  
default[:jnj_etcpasswd][:uid1]  
default[:jnj_etcpasswd][:home1]  
default[:jnj_etcpasswd][:gid1]  
default[:jnj_etcpasswd][:comment1]  


Recipes


default
-------

License and Author


- Author:: Praneeta Kumari (<praneeta.kumari@relevancelab.com>)

