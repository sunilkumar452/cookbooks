#
# Cookbook Name:: jnj_etcpasswd_nologin_new
# Recipe:: default
#
# Copyright 2016, Relevance Lab Pvt LTD, Inc.
#
# All rights reserved - Do Not Redistribute
#

(0..12).each do |a|

  group node['jnj_etcpasswd']['user'][a] do
  gid node['jnj_etcpasswd']['gid'][a]
  action :create
  not_if "grep #{node['jnj_etcpasswd']['gid'][a]} /etc/group"
  end
 end

(0..12).each do |s|
user node['jnj_etcpasswd']['user'][s] do
  uid node[:jnj_etcpasswd][:uid][s]
  gid node[:jnj_etcpasswd][:gid][s]
  home node[:jnj_etcpasswd][:home][s]
  shell node[:jnj_etcpasswd][:shell]
  comment  node[:jnj_etcpasswd][:comment][s]
  action :create
  
end
end

user 'pe-puppet' do 
   comment 'Privilage-seperated SSH'
   home '/var/opt/lib/pe-puppet'
   shell '/sbin/nologin'
 end

if node['platform_version'].to_i == 6.0

	(0..12).each do |a|

  		group node['jnj_etcpasswd']['user1'][a] do
 		 gid node['jnj_etcpasswd']['gid1'][a]
  		action :create
  		not_if "grep #{node['jnj_etcpasswd']['gid1'][a]} /etc/group"
  	end
 end


(0..12).each do |p|
		user node[:jnj_etcpasswd][:user1][p] do
  		gid node[:jnj_etcpasswd][:gid1][p]
  		uid node[:jnj_etcpasswd][:uid1][p]
  		home node[:jnj_etcpasswd][:home1][p]
  		shell node[:jnj_etcpasswd][:shell]
  		comment  node[:jnj_etcpasswd][:comment1][p]
  
	end
end
end