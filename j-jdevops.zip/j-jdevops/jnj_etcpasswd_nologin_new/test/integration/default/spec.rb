
user = ['bin', 'daemon', 'adm', 'lp', 'sync', 'mail', 'operator', 'games', 'gopher', 'ftp', 'nobody', 'dbus', 'sshd' ]
uid  = [1, 2, 3, 4, 5, 8, 11, 12, 13, 14, 99, 81, 74]
gid  = [1, 2, 4, 7, 0, 12, 0, 100, 30, 50, 99, 81, 74]
home = %w{/bin /sbin /var/adm /var/spool/lpd /sbin /var/spool/mail /root /usr/games /var/gopher /var/ftp / / /var/empty/sshd }

 (0..12).each do |a|
		describe user( user[a] ) do
 		its('uid') { should eq uid[a] }
 		its('gid') { should eq gid[a] }
 		its('home') { should eq home[a] }
 		its('shell') { should eq '/sbin/nologin'}
		end
	end



s = os[:release] 

if s.to_i == 6

		user1 = %w{uucp oprofile rpcuser rpc ntp haldaemon vcsa tcpdump abrt saslauth nfsnobody halt shutdown}
		uid1 = [ 10, 16, 29, 32, 38, 68, 69, 72, 173, 499, 65534, 7, 6 ]
		home1 = %w{/var/spool/uucp /home/oprofile /var/lib/nfs /var/cache/rpcbind /etc/ntp / /dev / /etc/abrt  /var/empty/saslauth  /var/lib/nfs /sbin /sbin}
		gid1 = [14, 16, 29, 32, 38, 68, 69, 72, 173, 76, 65534, 0, 0 ]

		(0..12).each do |a|
				describe user(user1[a]) do
 				its('uid') { should eq uid1[a] }
 				its('gid') { should eq  gid1[a] }
 				its('home') { should eq  home1[a] }
 				its('shell') { should eq '/sbin/nologin'}
			end
	    end
end


