default['jnj_hostname']['host']['name'] = 'variable'
