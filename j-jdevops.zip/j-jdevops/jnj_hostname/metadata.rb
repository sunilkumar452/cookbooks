name             'jnj_hostname'
maintainer       'Relevance Lab'
maintainer_email 'krishna.vudumula@relevancelab.com'
license          'All rights reserved'
description      'Installs/Configures hostname'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '0.1.0'
issues_url 'https://github.com/chef-cookbooks/chef-client/issues'
source_url 'https://github.com/chef-cookbooks/chef-client'
