#
# Cookbook Name:: jnj_hostname
# Recipe:: default
#
# Copyright 2016, YOUR_COMPANY_NAME
#
# All rights reserved - Do Not Redistribute

fact_hostname = node['hostname'].downcase
vpcx_hostname = node['jnj_hostname']['host']['name']

if node['hostname'] != vpcx_hostname && vpcx_hostname != ''
  if node['platform_version'].to_i == 6
    execute 'run_command' do
      command "hostname #{vpcx_hostname}; sed -i s/HOSTNAME=.*/HOSTNAME=#{vpcx_hostname}/g /etc/sysconfig/network"
    end
  elsif node['platform_version'].to_i == 7
    execute 'run_command' do
      command "hostnamectl set-hostname #{vpcx_hostname}"
    end
  end
  execute 'Replace_Hostname_in_Hosts_Mapping' do
    command "sed -i s/#{fact_hostname}/#{vpcx_hostname}/g /etc/hosts"
    only_if "grep #{fact_hostname} /etc/hosts"
  end

end
