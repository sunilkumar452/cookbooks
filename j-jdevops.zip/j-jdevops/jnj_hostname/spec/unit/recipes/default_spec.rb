#
# Cookbook Name:: jnj_hostname
# Spec:: default
#
# Copyright (c) 2016 The Authors, All Rights Reserved.

require 'spec_helper'
describe 'jnj_hostname::default' do

  context 'When all attributes are default, on an RHEL6 platform' do
    let(:chef_run) do
      runner = ChefSpec::ServerRunner.new(platform: 'redhat', version: '6.0')
      runner.converge(described_recipe)
    end

    it 'replaces hostname in /etc/hosts' do
      stub_command('grep fauxhai /etc/hosts').and_return(true)
      expect(chef_run).to run_execute('hostname variable; sed -i s/HOSTNAME=.*/HOSTNAME=variable/g /etc/sysconfig/network')
    end
  end

  context 'When all attributes are default, on an RHEL7 platform' do
    let(:chef_run) do
      runner = ChefSpec::ServerRunner.new(platform: 'redhat', version: '7.0')
      runner.converge(described_recipe)
    end

    it 'sets hostname in version 7' do
      stub_command('grep fauxhai /etc/hosts').and_return(true)
      expect(chef_run).to run_execute('sed -i s/fauxhai/variable/g /etc/hosts')
      expect(chef_run).to run_execute('hostnamectl set-hostname variable')
    end
  end

end
