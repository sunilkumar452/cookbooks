control 'jnj_hostname' do
  describe command('hostname') do
    its('stdout') { should match(/variable/) }
  end

  osver7 = os[:release].to_i
  if osver7 == 7
    describe command('hostnamectl') do
      its('stdout') { should match(/variable/) }
    end
  end

  describe file('/etc/hosts') do
    its('content') { should match(/variable/) }
  end
end
