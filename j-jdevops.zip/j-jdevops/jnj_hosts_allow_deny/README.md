# jnj_hosts_allow_deny Cookbook
=========================

Description
===========
This cookbook looks for the hostname of user and check whether should allow or deny.

Requirements
============

## Platforms

* Red Hat/CentOS/Scientific (6.0+ required) - "EL6-family"

Tested on:

* CentOS 7.1

Usage:
Chef-client run

## Cookbooks

None

Attributes
==========
None

Recipes
=======

default
-------

License and Author
==================

- Author:: Phaneendra <chinthalapalli.phaneendra@relevancelab.com>

