name             'jnj_hosts_allow_deny'
maintainer       'Relevance Lab'
maintainer_email 'chinthalapalli.phaneendra@relevancelab.com'
license          'All rights reserved'
description      'Installs/Configures hosts_allow_deny'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '0.1.0'
issues_url 'https://github.com/chef-cookbooks/chef-client/issues'
source_url 'https://github.com/chef-cookbooks/chef-client'
