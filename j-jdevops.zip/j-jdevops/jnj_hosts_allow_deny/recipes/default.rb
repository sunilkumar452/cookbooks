#
# Cookbook Name:: jnj_hosts_allow_deny
# Recipe:: default
#
# Copyright 2016, Relevance Lab
#
# All rights reserved - Do Not Redistribute
#
cookbook_file '/etc/hosts.allow' do
  source 'hosts_allow'
  owner 'root'
  group 'root'
  mode  '0644'
end
cookbook_file '/etc/hosts.deny' do
  source 'hosts_deny'
  owner 'root'
  group 'root'
  mode  '0644'
end
