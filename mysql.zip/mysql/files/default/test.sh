#!/bin/bash

mysql -u root <<EOF
create database testdb;
create user 'testuser'@'localhost' identified by 'password';
grant all on testdb.* to 'testuser' identified by 'password';
exit
EOF
