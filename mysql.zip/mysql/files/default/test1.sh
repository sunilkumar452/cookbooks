#!/bin/bash
mysql -u root-proot <<EOF
SET PASSWORD FOR 'root'@'localhost'=PASSWORD('root');
CREATE USER 'slz02'@'localhost' IDENTIFIED BY 'slz02@123';
GRANT ALL PRIVILEGES ON `slz_core`.* TO 'slz02'@'%';
Create Database slz_custportal;
Create Database slz_portal;
Create Database litpro;
Create Database litpro_reports;
Create Database slz_core;
exit
EOF
