#
# Cookbook Name:: mysql
# Recipe:: default
#
# Copyright 2017, YOUR_COMPANY_NAME
#
# All rights reserved - Do Not Redistribute
#

execute 'installing mysql' do
	command "sudo yum install mysql-server -y"
end

execute 'Enabling on' do
	command "sudo /sbin/chkconfig --levels 235 mysqld on"
end

service "mysqld" do
  action :start
end

cookbook_file '/opt/test.sh' do
  source 'test.sh'
  mode '0755'
  action :create
end

cookbook_file '/opt/test1.sh' do
  source 'test1.sh'
  mode '0755'
  action :create
end

execute 'run the test' do
	cwd '/opt'
	command "sudo sh test.sh"
end

execute 'run the test1' do
    cwd '/opt'
    command "sudo sh test1.sh"
end
